# coding=utf-8

STREAM = "BINLOG"  # "BINLOG" or "INIT"
SERVER_ID = 99
SLAVE_UUID = __name__

# 一次同步 BULK_SIZE 条数据到elasticsearch
BULK_SIZE = 100

BINLOG_CONNECTION = {
    'host': '172.18.0.125',
    'port': 8000,
    'user': 'root',
    'passwd': 'Kc#123456'
}

# redis存储上次同步位置等信息
REDIS = {
    "host": "172.18.0.125",
    "port": 6379,
    "db": 0,
    "password": "Xbu0dJ1Z2IpI",
}

# ES配置
NODES = [{"host": "172.18.0.125", "port": 9200}]

TASKS = [
    {
        "stream": {
            "database": "kaochong_order",
            "table": "tb_kc_order_0"
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",
            "table": "tb_kc_order_1"
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",
            "table": "tb_kc_order_2"
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",
            "table": "tb_kc_order_3"
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",
            "table": "tb_kc_order_4"
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",
            "table": "tb_kc_order_5"
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",
            "table": "tb_kc_order_6"
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",
            "table": "tb_kc_order_7"
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    }
]

CUSTOM_ROW_HANDLERS = "./my_handlers.py"
# CUSTOM_ROW_FILTERS = "./my_filters.py"
