# coding=utf-8

STREAM = "INIT"

# 修改数据库连接
CONNECTION = {
    'host': '172.18.0.125',
    'port': 8000,
    'user': 'root',
    'passwd': 'Kc#123456'
}

# 一次同步 BULK_SIZE 条数据到elasticsearch，不设置该配置项默认为1
BULK_SIZE = 1

# 修改elasticsearch节点
NODES = [{"host": "172.18.0.125", "port": 9200}]

TASKS = [
    {
        "stream": {
            "database": "kaochong_order",  # 在此数据库执行sql语句
            "sql": "select * from tb_kc_order_0",  # 将该sql语句选中的数据同步到 elasticsearch
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",  # 在此数据库执行sql语句
            "sql": "select * from tb_kc_order_1",  # 将该sql语句选中的数据同步到 elasticsearch
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",  # 在此数据库执行sql语句
            "sql": "select * from tb_kc_order_2",  # 将该sql语句选中的数据同步到 elasticsearch
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",  # 在此数据库执行sql语句
            "sql": "select * from tb_kc_order_3",  # 将该sql语句选中的数据同步到 elasticsearch
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",  # 在此数据库执行sql语句
            "sql": "select * from tb_kc_order_4",  # 将该sql语句选中的数据同步到 elasticsearch
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",  # 在此数据库执行sql语句
            "sql": "select * from tb_kc_order_5",  # 将该sql语句选中的数据同步到 elasticsearch
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",  # 在此数据库执行sql语句
            "sql": "select * from tb_kc_order_6",  # 将该sql语句选中的数据同步到 elasticsearch
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    },
    {
        "stream": {
            "database": "kaochong_order",  # 在此数据库执行sql语句
            "sql": "select * from tb_kc_order_7",  # 将该sql语句选中的数据同步到 elasticsearch
        },
        "jobs": [
            {
                "actions": ["insert", "update"],
                "pipeline": [
                    {"merge_detail": {}},
                    {"merge_coupon": {}},
                    {"set_id": {"field": "order_id"}}
                ],
                "dest": {
                    "es": {
                        "action": "upsert",
                        "index": "kc_order_index",
                        "type": "kc_order",
                        "nodes": NODES
                    }
                }
            }
        ]
    }
]

CUSTOM_ROW_HANDLERS = "./my_handlers.py"
# CUSTOM_ROW_FILTERS = "./my_filters.py"
