#!/bin/sh

cd /home/kaochong/app/mysql2es_qa
nohup mom run -c ./init_config.py >> out-init.txt &

