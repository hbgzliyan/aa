# coding=utf-8
import copy
import pymysql
from DBUtils.PooledDB import PooledDB

pool = PooledDB(pymysql, 10, host='172.18.0.125',user='root',passwd='Kc#123456',db='kaochong_order',port=8000,charset="utf8") 

def merge_detail(row):

    new_row = copy.deepcopy(row)
    ret = [];
    try:
        conn = pool.connection() 
        cur = conn.cursor()
        SQL = "select * from `tb_kc_order_detail_" + str(new_row['order_id'] % 10) + "` where order_id = " + str(new_row['order_id'])
        r = cur.execute(SQL)
        fields = [desc[0] for desc in cur.description] 
        rst = cur.fetchall() 
        if rst: ret = [dict(zip(fields, row)) for row in rst]
    except Exception as e:
            print('Mysql Query ERROR:' + str(e))
    cur.close()
    conn.close()

    new_row['detail'] = ret;

    return new_row

def merge_coupon(row):

    new_row = copy.deepcopy(row)
    ret = [];
    try:
        conn = pool.connection() 
        cur = conn.cursor()
        SQL = "select * from `tb_kc_order_coupon_record` where order_id = " + str(new_row['order_id'])
        r = cur.execute(SQL)
        fields = [desc[0] for desc in cur.description] 
        rst = cur.fetchall() 
        if rst: ret = [dict(zip(fields, row)) for row in rst]
    except Exception as e:
            print('Mysql Query ERROR:' + str(e))
    cur.close()
    conn.close()

    new_row['coupon'] = ret;

    return new_row
